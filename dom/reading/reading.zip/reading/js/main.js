const h1 = document.querySelector("h1");
console.dir(h1);