const greeting = name => `Hello ${name}!`;

export { greeting };