import { greeting } from "./lib.js";
console.log("main.js loaded");

console.log(greeting("Mia"));